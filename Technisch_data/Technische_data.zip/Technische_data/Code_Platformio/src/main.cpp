#include <Arduino.h>

/*!
 * Werking programma:*****
 *
 * Laatste update: 22/04/2024
 * 
 * Het programma is een 1-dimensionale versie van het bekende spel "Pong". De bedoeling is dat de speler probeert om de brandende LED
 * heen en weer te sturen zonder dat de LED 'voorbij' de rode LED gaat. Hoe langer de speler wacht met de LED terug te sturen, des
 * te sneller de LED terug gestuurd wordt. Wanneer de speler te lang wacht en de brandende LED zogezegd 'voorbij' de rode LED gaat,
 * dan is de speler verloren. Dit is duidelijk te zien aan de knipperende LED. Aan het begin van het spel zit er ook een kleine
 * begin-animatie.
 *
 * 
 * Indien het spel sneller of trager moet, dient u de constanten in de "speed"-array aan te passen. Dit is de tijd tussen 2 LEDs
 * uitgedrukt in ms.
 *
 */

const int led[] = {2, 1, 0, 4, 5, 6, 7, 8, 10, 20};     //pinnen bij overeenkomstige led (Led 1 = pin 2, Led 2 = pin 1, ...)
int speed_left = 150;           //speed when going left
int speed_right = 150;          //speed when going right
int last_button = 0;            //laatst ingedrukt: 0 = start, 1 = links (leds naar rechts), 2 = rechts (leds naar links)
int led_on = 0;                 //houd laatst brandende led bij
bool game_playing = false;      //true indien er gespeeld wordt

unsigned long button_time = 0;
unsigned long previous_button_time = 0;


//left button interrupt
void IRAM_ATTR leftButton() {
  button_time = millis();
  if (button_time - previous_button_time > 250 && last_button != 1) {
    last_button = 1;
    previous_button_time = button_time;
  }
}

//right button interrupt
void IRAM_ATTR rightButton() {
  button_time = millis();
  if (button_time - previous_button_time > 250 && last_button != 2) {
    last_button = 2;
    previous_button_time = button_time;
  }
}


void setup() {
  //pinMode LEDs
  for (int i = 0; i < 10; i++) {
    pinMode(led[i], OUTPUT);
  }

  //pinMode buttons
  pinMode(3, INPUT);        //left
  pinMode(21, INPUT);       //right

  //Interrupt Service Routine
  attachInterrupt(digitalPinToInterrupt(3), leftButton, RISING);
  attachInterrupt(digitalPinToInterrupt(21), rightButton, RISING);

  game_playing = true;
}


void loop() {
  //Begin game animation, starts after each game
  if (last_button == 0 && game_playing) {
    for (int i = 1; i < 5; i++) {
      digitalWrite(led[i], HIGH);
      digitalWrite(led[9 - i], HIGH);
      delay(750);
      digitalWrite(led[i], LOW);
      digitalWrite(led[9 - i], LOW);
    }

    delay(400);
    led_on = 3;
    last_button = 1;
  }


  //Left button pressed (LEDs left to right)
  if (last_button == 1 && game_playing) {
    for (int i = led_on; i < 10; i++) {
      digitalWrite(led[i], HIGH);
      delay(speed_right);
      digitalWrite(led[i], LOW);

      if (last_button == 2) {
        if (i == 9) {
          speed_left *= 0.9;
        }
        led_on = i;
        break;
      }
    }

    if (last_button != 2) {
      game_playing = false;
      for (int i = 0; i < 5; i++) {
        digitalWrite(led[9], HIGH);
        delay(500);
        digitalWrite(led[9], LOW);
        delay(500);   
      }
    }
  }


  //Right button pressed (LEDs right to left)
  if (last_button == 2 && game_playing) {
    for (int i = led_on; i >= 0; i--) {
      digitalWrite(led[i], HIGH);
      delay(speed_left);
      digitalWrite(led[i], LOW);

      if (last_button == 1) {
        if (i == 0) {
          speed_right *= 0.9;
        }
        led_on = i;
        break;
      }
    }

    if (last_button != 1) {
      game_playing = false;
      for (int i = 0; i < 4; i++) {
        digitalWrite(led[0], HIGH);
        delay(500);
        digitalWrite(led[0], LOW);
        delay(500);
      }
    }
  }

  //small break at the end of the game, resets some parameters
  if (!game_playing) {
    delay(2000);
    game_playing = true;
    last_button = 0;
    speed_left = 150;
    speed_right = 150;
  }
}


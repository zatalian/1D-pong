Gegevens zijn afkomstig uit EasyEda

Inhoud:

- Schema (SCH_1D-pong-2024_2024-05-22)
	--> Elektrische schakeling
- PCB (PCB_PCB_1D-pong-2024-versie-1_2024-05-22)
	--> Printed Circuit Board (PCB)
- Gerber bestand (Gerber_1D-pong-2024_PCB_1D-pong-2024-versie-1_2024-05-22)
	--> Nodig om de PCB direct te bestellen
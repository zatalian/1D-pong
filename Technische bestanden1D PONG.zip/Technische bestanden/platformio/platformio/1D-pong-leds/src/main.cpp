#include <Arduino.h>
//#include <Adafruit_NeoPixel.h>


//#define PIN 6
//#define NUMPIXELS 12
#define LENGTH 9000000
//Adafruit_NeoPixel pixels(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);

const int led[] = {1, 2, 3, 4, 5, 6, 7, 8, 10, 20};

unsigned int state = 0;
int position = -1;
int speed = 0;
int bounced = -1;

void leftButton()
{
  if ((state == 0) || (state == 2)) state = 3;
}

void rightButton()
{
  if ((state == 0) || (state == 2)) state = 4;

}


void setup() 
{
  Serial.begin(115200);
  
  // add eventhandler to WiFi connection
/*  WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info)
  {
    Serial.printf("WiFi event: %d\n", event);
    switch (event)
    {
      case SYSTEM_EVENT_STA_GOT_IP:
        Serial.print("IP address: ");
        Serial.println(WiFi.localIP());
        break;
      case SYSTEM_EVENT_STA_DISCONNECTED:
        Serial.println("WiFi lost connection");
        break;
      default:
        break;
    }
  });

  // WiFi transmit power hack for Wemos C3 mini
  
  WiFi.begin("HGDevice", "KillAllHuman$");
WiFi.setTxPower(WIFI_POWER_8_5dBm);

  // setup arduino ota
  ArduinoOTA.setHostname("ESP32");
  // connect to wifi
  
  ArduinoOTA.begin();
*/
  // put your setup code here, to run once:
  /*pixels.begin();
  pixels.setPixelColor(0, pixels.Color(255, 0, 0));
  pixels.setPixelColor(7, pixels.Color(0, 0, 255));
  pixels.show();*/


  // set build in LED as output
  pinMode(LED_BUILTIN, OUTPUT);

  // define pin 1 and pin 2 as digital input with interrupt
  pinMode(0, INPUT);
  pinMode(21, INPUT);
  attachInterrupt(digitalPinToInterrupt(0), leftButton, RISING);
  attachInterrupt(digitalPinToInterrupt(21), rightButton, RISING);


  // set all leds as output
  for (int i = 0; i < 10; i++)
  {
    pinMode(led[i], OUTPUT);
  }
  // start neopixel
  //pixels.begin();
  // clear all pixels
  //pixels.clear();
  // show pixels
  //pixels.show();

}

// create interrupt function for pin 1 and pin 2

unsigned long previous = 0;
unsigned long startWait = 0;
unsigned int prevState = 0;

void loop() 
{
  unsigned long current = millis();
  unsigned long difference = current - previous;
  previous = current;
  position += (difference * speed);
  int distance = (speed > 0 ? LENGTH - position : position);

  switch (state)
  {
    case 0:
      speed = 0;
      position = -1;
      bounced = -1;
      break;  

    case 1:
      if (distance < LENGTH / 4) state = 2;
      break;

    case 2:
      if ((distance < 0) || (distance > LENGTH)) state = 5;
      break;

    case 3:
    case 4:
      if (bounced < 0)  // start
      {
        speed = (state == 3 ? 3000 : -3000);
        position = (state == 3 ? 0 : LENGTH);
        bounced = position;
        state = 1;
      }
      else  // bounce
      {
        speed = (speed >= 0 ? -1 : 1);
        int absSpeed = (3000.0 - 10000.0) / (LENGTH / 4) * distance + 10000; 
        speed *= absSpeed;
        bounced = position;
        state = 1;
      }
      break;  
    case 5:
      position = -1;
      speed = 0;
      bounced = -1;
      startWait = current;
      state = 6;
      break;  

    case 6:
      if (current - startWait > 2000) state = 0;
      break;  
  }

 /* if (state != prevState)
  {
    Serial.print("state: ");
    Serial.println(state);
    Serial.print("position: ");
    Serial.println(position);
    Serial.print("speed: ");
    Serial.println(speed);
    prevState = state;
  } */

  //pixels.clear();
  if (position >= 0)
  {
    int index = round(((float) position) / 1000000);
    // set led on position index high, all other low
    for (int i = 0; i < 10; i++)
    {
      digitalWrite(led[i], (i == index ? HIGH : LOW));
    }

    // set pixel color to red on position led
    //pixels.setPixelColor(led, pixels.Color(70, 0, 0));

    // set pixel on position led to rainbow color based on position and intensity based on speed
    //int intensity = 30;
    //pixels.setPixelColor(led, pixels.ColorHSV(round(65535.0 / 11000000.0 * position), 255, intensity));
  }
  else
  {
    // set all leds low
    for (int i = 0; i < 10; i++)
    {
      digitalWrite(led[i], LOW);
    }
  }
  //pixels.show();

  

  delay(1);
}
21 x behuizing ledstrip:
	voor 1 behuizing: - 1x grondplaat ledstrip
				- 1x achterplaat ledstrip kabel
				- 1x achterplaat ledstrip
				- 2x zijplaat ledstrip
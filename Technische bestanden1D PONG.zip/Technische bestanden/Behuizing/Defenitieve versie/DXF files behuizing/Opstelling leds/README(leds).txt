21 x behuizing leds:
	voor 1 behuizing: - 1x grondplaat
				- 2x achterplaat
				- 2x zijplaat